package com.myday.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.Calendar

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val now = Calendar.getInstance()
        val hour = now.get(Calendar.HOUR_OF_DAY)
        // Reminder window: 8 AM through 10 PM. WorkManager is inexact and may delay delivery.
        if (hour in 8..22) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                manager.getNotificationChannel(CHANNEL_ID) == null) {
                manager.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "My Day reminders", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val index = (hour + now.get(Calendar.DAY_OF_YEAR)) % messages.size
            val notification: Notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("My Day")
                .setContentText(messages[index])
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            manager.notify(1000 + hour, notification)
        }
        return Result.success()
    }

    companion object {
        const val CHANNEL_ID = "my_day_hourly"
        private val messages = listOf(
            "Start small. One focused step is progress.",
            "Your future is built by what you do today.",
            "Pause, breathe, and return to your most important task.",
            "Consistency matters more than a perfect day.",
            "Make time for learning, prayer, and rest.",
            "Discipline is choosing what matters over what is easy.",
            "Review your goals and take the next step.",
            "A little progress today is better than waiting for perfect."
        )
    }
}
